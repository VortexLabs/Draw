'use strict';

var domready = require('domready');

/**
 * main module.
 * @module main
 */

domready(function () {

  require('./ui/index.jsx');

});

