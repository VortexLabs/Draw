'use strict';

var React   = require('react');
var Router  = require('react-router');
var Link    = Router.Link;
var YouTube = require('youtube-iframe-player');

var ComponentYoutube = require('../../components/youtube/index.jsx');
var ComponentImage   = require('../../components/image/index.jsx');
var ComponentCycle   = require('../../components/cycle/index.jsx');

var MAX_MEDIA = 6; // Total number of media items in the gallery.

var SectionFullscreen = React.createClass({
	contextTypes: {
		router : React.PropTypes.func
	},
	getInitialState: function () {
    return {
      id : this.context.router.getCurrentParams().id
    };
	},
	next: function () {
		var next = (parseInt(this.state.id) + 1);
		next = (next > MAX_MEDIA) ? 1 : next;
		return next;
	},
	previous: function () {
		var previous = (parseInt(this.state.id) - 1);
		previous = (previous == 0) ? MAX_MEDIA : previous;
		return previous;
	},
	media: function () {
		if (this.isVideo(this.state.id)) {
			return <ComponentYoutube />;
		}
		return <ComponentImage id={this.state.id} />;
	},
	isVideo: function () {
		return (this.state.id == '6');
	},
  render: function () {
  	var media    = this.media();
  	var next      = this.next();
  	var previous  = this.previous();
    return (
      <section className="section section-fullscreen">
        <div className="fullscreenMedia">{media}</div>
        <Link to="/gallery" className="close">CLOSE</Link>
        <ComponentCycle previous={previous} next={next} current={this.state.id} total={MAX_MEDIA} />
      </section>
    );
  }
});

module.exports = SectionFullscreen;
