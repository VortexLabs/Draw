'use strict';

var React = require('react');

var SectionSynopsis = React.createClass({
  render: function() {
  	var justify   = this.props.justify;
  	var className = (this.props.getClass) ? this.props.getClass('synopsis', justify, this.props.menu) : 'section';
    return (
      <section className={className}>
      <div className="menuItem menuTop">TOP</div>
      <div className="menuItem menuBottom">BOTTOM</div>
        <h1>SYNOPSIS</h1>
      </section>
    );
  }
});

module.exports = SectionSynopsis;
