'use strict';

var React = require('react');

var SocialFeed = require('../../components/socialfeed/index.jsx');

var SectionHome = React.createClass({
  handleWheel: function( event ) {
    console.log( event.deltaX );
  },
  render: function() {
  	var justify   = this.props.justify;
  	var className = (this.props.getClass) ? this.props.getClass('home', justify, this.props.menu) : 'section';
    return (
      <section className={className} onWheel={this.handleWheel}>
        <div className="inner-container">
          <h1>HOME</h1>
          <h2>Spredfast Test</h2>
          <SocialFeed feedUrl="http://api.massrelevance.com/ppmassrelevance/test.json" />
        </div>
      </section>
    );
  }
});

module.exports = SectionHome;
