'use strict';

var React        = require('react');
var Router       = require('react-router');
var RouteHandler = Router.RouteHandler;
var Link         = Router.Link;

var SectionGallery = React.createClass({
  render: function () {
    var justify   = this.props.justify;
    var className = (this.props.getClass) ? this.props.getClass('gallery', justify, this.props.menu) : 'section';
    return (
      <section className={className}>
        <div className="menuItem menuTop">TOP</div>
        <h1>GALLERY</h1>
        <ul>
        	<li><Link to="gallery-fullscreen" params={{id: 1}}><img src="/images/gallery/1.jpeg" alt="1" width="200" /></Link></li>
        	<li><Link to="gallery-fullscreen" params={{id: 2}}><img src="/images/gallery/2.jpeg" alt="2" width="200" /></Link></li>
        	<li><Link to="gallery-fullscreen" params={{id: 3}}><img src="/images/gallery/3.jpeg" alt="3" width="200" /></Link></li>
        	<li><Link to="gallery-fullscreen" params={{id: 4}}><img src="/images/gallery/4.jpeg" alt="4" width="200" /></Link></li>
        	<li><Link to="gallery-fullscreen" params={{id: 5}}><img src="/images/gallery/5.jpeg" alt="5" width="200" /></Link></li>
        	<li><Link to="gallery-fullscreen" params={{id: 6}}>Video</Link></li>
        </ul>
      </section>
    );
  }
});

module.exports = SectionGallery;
