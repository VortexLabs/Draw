
var React              = require('react/addons');
var Router             = require('react-router');
var Route              = Router.Route;
var Redirect           = Router.Redirect;
var DefaultRoute       = Router.DefaultRoute;
var NotFoundRoute      = Router.NotFoundRoute;
var RouteHandler       = Router.RouteHandler;

var CSSTransitionGroup = React.addons.CSSTransitionGroup;

// Here we define all our material-ui ReactComponents.
var ComponentHeader    = require('./components/header/index.jsx');
var ComponentNav       = require('./components/nav/index.jsx');
var ComponentMenu      = require('./components/menu/index.jsx');

var SectionHome        = require('./sections/home/index.jsx');
var SectionSynopsis    = require('./sections/synopsis/index.jsx');
var SectionGallery     = require('./sections/gallery/index.jsx');
var SectionFullscreen  = require('./sections/fullscreen/index.jsx');

var _sections = {
  "HOME"     : 0,
  "SYNOPSIS" : 1,
  "GALLERY"  : 2,
  "COUNT"    : 3
};

var _paths = {
  "root"              : "/",
  "synopsis"          : "/synopsis",
  "gallery"           : "/gallery",
  "galleryFullscreen" : "/gallery/fullscreen/"
};

var _previousPath = null;

/** Routes: https://github.com/rackt/react-router/blob/master/docs/api/components/Route.md
 *
 * Routes are used to declare your view hierarchy.
 *
 * Say you go to http://material-ui.com/#/components/paper
 * The react router will search for a route named 'paper' and will recursively render its
 * handler and its parent handler like so: Paper > Components > Master
 */

var App = React.createClass({
  contextTypes: {
    router: React.PropTypes.func
  },
  currentPath: function () {
    return this.context.router.getCurrentPath();
  },
  configuration: function () {
    var path  = this.currentPath();
    var trans = this.transition(_previousPath, path);

    _previousPath = path;

    return {
      "path"  : path,
      "trans" : trans,
    };
  },
  transition: function (prevPath, curPath) {
    var prevOrder  = this.getPathOrderForPath(prevPath);
    var curOrder   = this.getPathOrderForPath(curPath);
    var diff       = (curOrder - prevOrder);
    var identifier = 0;
    var trans      = null;

    if (diff > 100) {
      trans = 'menuEnter';
    } else if (diff < -100) {
      trans = 'menuExit';
    } else if (diff > 0) {
      if (diff % 10 == 0) {
        trans = 'pageTrans';
      } else {
        trans = 'overlayTrans';
      }
    } else if (diff < 0) {
      if (diff % 10 == 0) {
        trans = 'pageTransReverse';
      } else {
        trans = 'overlayTransClose';
      }
    } else {
      identifier = curOrder;
      curOrder   = this.getPathOrderFromPath(curPath);
      prevOrder  = this.getPathOrderFromPath(prevPath);
      diff       = (curOrder - prevOrder);

      if (diff == 1 || diff < -1) {
        if (identifier == 1001) {
          trans = 'menuCycleNext';
        } else {
          trans = 'fullscreenCycleNext';
        }
      } else {
        if (identifier == 1001) {
          trans = 'menuCyclePrevious';
        } else {
          trans = 'fullscreenCyclePrevious';
        }
      }
    }

    return trans;
  },
  getPathOrderFromPath : function (path) {
    if (!path) {
      // TO DO
      return 1;
    }

    var idx = path.lastIndexOf('/');
    var id  = path.substring(idx + 1);

    return parseInt(id);
  },
  getPathOrderForPath: function (path) {
    if (!path)
      return -10;

    switch (path) {
      case _paths.root:
        return 0;
      case _paths.synopsis:
        return 10;
      case _paths.gallery:
        return 20;
      default:
        break;
    }

    if (path.indexOf(_paths.galleryFullscreen) > -1)
      return 21;
    return -10;
  },
  getIndexForPath: function (path) {
    if (!path)
      return 0;

    switch (path) {
      case _paths.root:
        return 0;
      case _paths.synopsis:
        return 1;
      case _paths.gallery:
        return 2;
    }

    return 0;
  },
  render: function () {
    var config = this.configuration();
    var path   = config.path;
    var trans  = config.trans;
    var index  = this.getIndexForPath(path);

    return (
      <div className="main-container">
        <AppMenu trans={trans} index={index} path={this.currentPath} />
      </div>
    );
  }
});

var AppMenu = React.createClass({
  contextTypes: {
    router: React.PropTypes.func
  },
  getInitialState: function () {
    return {
      currentIndex         : 0,
      menuActive           : false,
      transitionInProgress : false
    };
  },
  componentDidMount: function () {
    // window.addEventListener('resize', this.handleScrollEvent);
    // window.addEventListener('mousewheel', this.handleScrollEvent);
    // window.addEventListener('DOMMouseScroll', this.handleScrollEvent);
    // window.addEventListener('onmousewheel', this.handleScrollEvent); 

    // window.onkeyup = this.handleKeyEvent;
  },
  handleScrollEvent: function (e) {
    if (e.wheelDeltaY > 10) { // Scroll up.
      this.previousSection();
    } else if (e.wheelDeltaY < -10) { // Scroll down.
      this.nextSection();
    }
  },
  handleKeyEvent: function (e) {
    switch (e.keyCode) {
      case 38: // Up arrow.
        this.previousSection();
        break;
      case 40: // Down arrow.
        this.nextSection();
        break;
      case 13: // Enter.
        this.selectSection();
        break;
      default:
        break;
    }
  },
  previousSection: function () {
    if (!this.state.transitionInProgress) {
      this.refs.nav.goToSection(this.updateIndex(false));
      this.setState({transitionInProgress: true});
      this.throttleTransition();
    }
  },
  nextSection: function () {
    if (!this.state.transitionInProgress) {
      this.refs.nav.goToSection(this.updateIndex(true));
      this.setState({transitionInProgress: true});
      this.throttleTransition();
    }
  },
  selectSection: function () {
    if (this.state.menuActive) {
      React.findDOMNode(this.refs.menu).click();
    }
  },
  throttleTransition: function () {
    var _ = this;
    setTimeout(function() {
      _.setState({transitionInProgress: false});
    }, 1500);
  },
  updateIndex: function (advance) {
    var currentIndex = 0;

    if (advance) {
      currentIndex = Math.min((_sections.COUNT - 1), this.state.currentIndex + 1);
    } else {
      currentIndex = Math.max(0, this.state.currentIndex - 1);
    }

    this.setState({currentIndex: currentIndex});

    return currentIndex;
  },
  handleMenuClick: function (e) {
    this.setState({menuActive : !this.state.menuActive});
  },
  classForIndex: function(section, justification, menu) {
    var className = (
      'section' + 
      ' section-' + section +
      ' section-' + justification
    );

    if (menu) {
      className += ' section-menu';
    }

    return className;
  },
  alterTransForMenu: function (trans) {
    if (trans == 'pageTrans' && this.state.menuActive) {
      return 'menuCycleNext';
    }

    if (trans == 'pageTransReverse' && this.state.menuActive) {
      return 'menuCyclePrevious';
    }

    return trans;
  },
  render: function() {
    var path  = this.props.path();
    var trans = this.alterTransForMenu(this.props.trans);

    return (
      <div className="appMenu" key="appMenu">
        <ComponentNav ref="nav" />
        <ComponentMenu ref="menu" handleClick={this.handleMenuClick} />
          <RouteHandler justify="middle" menu={this.state.menuActive} getClass={this.classForIndex} key={path} />
      </div>
    );
  }
});

var routes = (
  <Route handler={App} path="/">
    <DefaultRoute handler={SectionHome} />
    <Route name="synopsis" handler={SectionSynopsis} />
    <Route name="gallery" handler={SectionGallery}>
      <Route name="gallery-fullscreen" path="fullscreen/:id" handler={SectionFullscreen} />
    </Route>
    <NotFoundRoute handler={SectionHome}/>
  </Route>
);

module.exports = routes;
