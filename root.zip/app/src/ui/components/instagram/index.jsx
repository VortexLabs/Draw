/**
 * Image Post
 *
 * Props accepted: 
 * content - the object representation of the next post to be shown
 *
 * States:
 * current - the object representation of the current post
 * incoming - the object representation of the next post
 *
 * The Image Post component will render a single image tile on the social media wall.
 *
 * Transition Implementation Ideas:
 * 1. Upon a prop update, the next image will be rendered behind the current image, and a CSS 3D rotate animation will occur to reveal the new image
 * After the rotate is complete, the state will be updated again such that the incoming post becomes the current post
 *
 * 2. On ComponentWillUpdate
 */

'use strict';

var React  = require('react/addons');
var CSSTransitionGroup = React.addons.CSSTransitionGroup;

var InstagramPost = React.createClass({
	render: function() {
	  return (
        <li className="feed-item instagram">
          {this.props.content.caption.text}
          <img src={this.props.content.images.low_resolution.url} />
        </li>
	  );
	}
});

module.exports = InstagramPost;
