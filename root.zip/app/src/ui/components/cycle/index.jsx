'use strict';

var React  = require('react');
var Router = require('react-router');
var Link   = Router.Link;

var Cycle = React.createClass({
  render: function() {
    return (
      <div className="component-cycle">
        <ul>
          <li><Link to="gallery-fullscreen" params={{id: this.props.previous}}> PREVIOUS </Link></li>
          <li>{this.props.current} / {this.props.total}</li>
          <li><Link to="gallery-fullscreen" params={{id: this.props.next}}> NEXT </Link></li>
        </ul>
      </div>
    );
  }
});

module.exports = Cycle;
