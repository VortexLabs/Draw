'use strict';

/* PACKAGE */

var React = require('react');
var Router  = require('react-router');
var Navigation = require('react-router').Navigation;

var Header = React.createClass({

    mixins: [Navigation],

    componentDidMount: function() {
      //
    },

    navigate: function(url) {
      this.transitionTo(url);
    },

    render: function() {

      return (
        <header className="component-header" onClick={ this.navigate.bind(this, '/') }>
            <h2>Header desktop</h2>
        </header>
    );
  }
});

module.exports = Header;
