'use strict';

var React  = require('react');
var Router = require('react-router');
var Link   = Router.Link;

var Nav = React.createClass({
  goToSection: function (index) {
    var node = null;

    switch (index) {
      case 0:
        node = React.findDOMNode(this.refs.home);
        break;
      case 1:
        node = React.findDOMNode(this.refs.synopsis);
        break;
      case 2:
        node = React.findDOMNode(this.refs.gallery);
        break;
    }

    if (node) {
      node.click();
    }
  },
  render: function() {
    return (
      <nav className="component-nav">
        <ul>
          <li><Link ref="home" to="/">Home</Link></li>
          <li><Link ref="synopsis" to="/synopsis">Synopsis</Link></li>
          <li><Link ref="gallery" to="/gallery">Gallery</Link></li>
        </ul>
      </nav>
    );
  }
});

module.exports = Nav;
