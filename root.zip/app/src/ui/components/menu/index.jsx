'use strict';

var React  = require('react');
var Router = require('react-router');
var Link   = Router.Link;

var Menu = React.createClass({
	componentDidMount: function () {
		var node = React.findDOMNode(this.refs.menuButtonContainer);
		node.addEventListener('click', this.handleClick);
	},
	componentWillUnmount: function () {
		var node = React.findDOMNode(this.refs.menuButtonContainer);
	  node.removeEventListener('click', this.handleClick);    
	},
	handleClick: function (e) {
		this.props.handleClick(e);
	},
  render: function() {
    return (
      <div className="component-menu" ref="menuButtonContainer">MENU</div>
    );
  }
});

module.exports = Menu;
