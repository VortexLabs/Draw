/**
 * Social Feed
 *
 * Props accepted: 
 * feedUrl - the address of the feed
 *
 * The Social Feed component will render a wall with 24 tiles of social media content pulled from the feed specified in the props.
 *
 * The feed is populated and updated as follows:
 * 1. 24 initial posts will be pulled from the feed initially, and all 24 tiles on the wall will be populated
 * 2. Periodically, 6 new posts will be pulled from the feed every time
 * 3. The 6 new posts will randomly replace content currently on the wall, triggering the content update transitions on the updated tiles
 *
 * The tiles will be made up of TextPost and ImagePost components
 * - transitions should be triggered in the "componentDidUpdate"
 */

'use strict';

var React  = require('react');
var Router = require('react-router');
var getJSON = require('get-json');
var Link   = Router.Link;

var InstagramPost = require('../instagram/index.jsx');

var SocialFeed = React.createClass({
  getInitialState: function() {
    return {
      items: []
    };
  },
  componentDidMount: function() {
    console.log( "In ComponentDidMount" );
    getJSON( this.props.feedUrl + '?limit=5', function(err, data) {
      this.setState( { items: data } );
      console.log( data );
    }.bind(this) );
  },
  getMoreContent: function( event ) {
    var lastId = this.state.items[ this.state.items.length - 1 ].entity_id;
    getJSON( this.props.feedUrl + '?limit=5&start_id=' + lastId, function(err, data) {
      var updatedItems = this.state.items.concat( data ); 
      this.setState( { items: updatedItems } );
    }.bind(this) );
  },
  openLink: function ( event ) {
  	event.stopPropagation();
  	event.preventDefault();
  	window.open( event.target.href, "_blank", "width=600, height=450" );
  },
  render: function() {
  	// Function to render individual feed items
  	var createFeedItem = function( currentItem, index ) {
      var feedItemContent;

      switch( currentItem.network ) {
        case "twitter": {
          var replyUrl = "http://twitter.com/intent/tweet?in_reply_to=" + currentItem.entity_id;
          var retweetUrl = "http://twitter.com/intent/retweet?tweet_id=" + currentItem.entity_id;
          var favoriteUrl = "http://twitter.com/intent/favorite?tweet_id=" + currentItem.entity_id;

          var image = {};
          if( currentItem.entities.media ) {
            image = <img src={currentItem.entities.media[0].media_url} />
          }

          feedItemContent = (
            <li key={currentItem.entity_id} className="feed-item twitter">
              {currentItem.text}
              {image}
              <div className="feed-bottom-bar">
                <a href={replyUrl} onClick={this.openLink}>Reply</a>
                <a href={retweetUrl} onClick={this.openLink}>Retweet</a>
                <a href={favoriteUrl} onClick={this.openLink}>Favorite</a>
              </div>
            </li>
          );

          break;
        }
        case "instagram": {
          feedItemContent = (
            <InstagramPost key={currentItem.entity_id} content={currentItem} />
          );

          break;
        }
      }

  	  return feedItemContent;
  	}.bind(this);

    return (
      <div className="social-feed">
        <ul className="social-feed-container">
      	  {this.state.items.map(createFeedItem)}
        </ul>
        <div className="more-button" onClick={this.getMoreContent}>More</div>
      </div>
    );
  }
});

module.exports = SocialFeed;
