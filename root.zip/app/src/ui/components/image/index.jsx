'use strict';

var React = require('react');

var ComponentImage = React.createClass({
  getClass: function () {
    return ('component-image img' + this.props.id);
  },
  render: function () {
    var className = this.getClass();
    return (
      <div className={className}></div>
    );
  }
});

module.exports = ComponentImage;
