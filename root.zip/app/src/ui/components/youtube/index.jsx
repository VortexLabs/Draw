'use strict';

var React   = require('react');
var YouTube = require('youtube-iframe-player');

var ComponentYoutube = React.createClass({
  componentDidMount: function () {
    var scrubber      = React.findDOMNode(this.refs.scrubber);
    var controller    = React.findDOMNode(this.refs.youtubeControl);
    var youtubePlayer = null;
    var duration      = 0;
    
    this.setState({controller: controller});
    controller.addEventListener('click', handleYouTubeControlClick);

    YouTube.init(function () {
      youtubePlayer = YouTube.createPlayer('player', {
        width: '100%',
        height: '100%',
        videoId: 'gOW_azQbOjw',
        playerVars : {'autoplay' : 0, 'controls' : 0, 'showinfo' : 0, 'wmode': 'transparent', 'html5': 0, 'rel': 0, 'disablekb': 1, 'enablejsapi': 1},
        events: {
          'onReady': playerReady,
          'onStateChange': onPlayerStateChange
        }
      });

      var scrubberInterval = null;
      var currentTime      = 0;

      function playerReady(event) {
        duration = youtubePlayer.B.duration;
      }
   
      function onPlayerStateChange(event) {
        switch (event.data) {
          case 0: // Video ended.
          {
            clearInterval(scrubberInterval);
            resetVideo();
          }
            break;
          case 1: // Started playing.
          {
            scrubberInterval = setInterval(function() {
              currentTime = youtubePlayer.B.currentTime;
              updateScrubber(currentTime, duration);
            }, 100);
          }
            break;
          default:
          {
            clearInterval(scrubberInterval);
          }
            break;
        }
      }
    });

    function handleYouTubeControlClick (event) {
      var percentage = (event.layerX / window.innerWidth);
      var seekTime   = (percentage * duration);

      updateScrubber(seekTime, duration);
      youtubePlayer.seekTo(seekTime, true);
    };

    function updateScrubber(currentTime, duration) {
      var percentage = 0;

      if (duration > 0) {
        percentage = ((currentTime / duration) * 100);
      }

      scrubber.style.width = (percentage + '%');
    };

    function resetVideo () {
      updateScrubber(0, duration);
    };
  },
  render: function () {
    return (
      <div className="component-youtube">
        <div id="player"></div>
        <div className="youtubeControl" ref="youtubeControl">
          <div className="scrubber" ref="scrubber"></div>
        </div>
      </div>
    );
  }
});

module.exports = ComponentYoutube;
