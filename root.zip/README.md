@cody
@vincent

////////////////////////
////////////////////////
      
       Install
       
////////////////
////////////////////////

> http://phantomjs.org/

> run 'npm install'
> run 'npm install -g gulp'
> run 'npm install -g phantomjs'
> run 'npm install -g casperjs'
> configure your domain  (you should use http://www.ampps.com/)


///// :: LOCAL SERVER :: ////

:: Domain name ""

///////////////////////////

-- App --

$PATH_PROJECT/app      paramount-mi5-epk.app

-- Dist --

$PATH_PROJECT/dist     paramount-mi5-epk.dist

///////////////////////////


> run 'gulp serve' (start dev server)
> run 'gulp serve:dist' (dist package)





